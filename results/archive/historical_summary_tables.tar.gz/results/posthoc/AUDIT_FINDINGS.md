# Independent post-hoc audit of archived experimental outputs

This is a new statistical analysis of archived five-seed runs, **not new training runs**. Paired t tests use the same seed IDs and Holm correction within each dataset × outcome family across five comparators. No causal inference is claimed.

## cwru — proposed minus matched TopK-SGD

| Outcome | Difference | 95% CI | Holm p |
|---|---:|---:|---:|
| task1 | 0.0215865 | [-0.0111196, 0.0542926] | 0.5633 |
| task2 | 0.00936281 | [-0.0131672, 0.0318928] | 1 |
| payload_mb | 0 | [0, 0] | 1 |
| jain_participation | -0.398224 | [-0.418351, -0.378098] | 3.287e-06 |

## intel_sensor — proposed minus matched TopK-SGD

| Outcome | Difference | 95% CI | Holm p |
|---|---:|---:|---:|
| task1 | -0.0248115 | [-0.0326908, -0.0169323] | 0.003772 |
| task2 | -0.00383121 | [-0.012296, 0.0046336] | 1 |
| payload_mb | 0 | [0, 0] | 1 |
| jain_participation | -0.277572 | [-0.297283, -0.257862] | 1.278e-05 |

## uci_har — proposed minus matched TopK-SGD

| Outcome | Difference | 95% CI | Holm p |
|---|---:|---:|---:|
| task1 | 0.00712589 | [0.00254906, 0.0117027] | 0.04968 |
| task2 | -6.78656e-05 | [-0.000256291, 0.00012056] | 1 |
| payload_mb | 0 | [0, 0] | 1 |
| jain_participation | -0.317782 | [-0.347758, -0.287806] | 3.966e-05 |

## Important source-code and evidence limitations

- The processed UCI HAR, CWRU, and Intel `.npz` datasets are not included in the repository, so no new dataset-based training was run in this audit.
- `remaining_energy` is a synthetic state that decreases every participation and is clipped to zero. It is not physical energy or a hard per-client feasibility constraint; the scheduler uses a round budget based on synthetic costs.
- `costs` become identical across clients while freezing is inactive; budget is then 1.05 × the cost of the target number of clients. This makes the round-budget constraint nonbinding at the default setting.
- `scores` contain a normalized residual-energy term and gradient norm affinity, but the third communication-frugality component is zero for every client when freezing is inactive. Thus no default client-level communication-cost differentiation is demonstrated.
- The current `fmtl` is a surrogate head coupling, not a faithful reproduction of a named external FMTL solver.
- Statistical comparisons are exploratory post-hoc; Holm correction mitigates only the declared comparator family, not all possible analysis choices.
- No new personalized FL, clustered FL, or distinct-task dataset baseline was run; those reviewer concerns remain open.
